# Marketing Ops — Local Suite (v3.1.1)

Migrazione DB automatica integrata. Avvio:
```
pip install -r requirements.txt
copy .env.example .env
streamlit run streamlit_app.py
```
